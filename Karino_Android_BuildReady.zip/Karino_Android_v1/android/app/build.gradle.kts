plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace="ir.karino.app"
    compileSdk=35
    defaultConfig {
        applicationId="ir.karino.app"
        minSdk=24
        targetSdk=35
        versionCode=1
        versionName="1.0.0"
        buildConfigField("String","API_BASE_URL","\"http://10.0.2.2:3000/api/\"")
    }
    buildFeatures { compose=true; buildConfig=true }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.material:material-icons-extended:1.7.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
}

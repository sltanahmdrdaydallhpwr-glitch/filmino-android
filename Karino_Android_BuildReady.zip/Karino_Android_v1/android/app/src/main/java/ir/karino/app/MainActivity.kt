package ir.karino.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*

private val Primary=Color(0xFF2457F5)
private val Bg=Color(0xFFF7F7F8)
data class Service(val title:String,val seller:String,val price:String,val rating:String)
private val services=listOf(
 Service("طراحی لوگو حرفه‌ای","سارا دیزاین","۴۵۰٬۰۰۰ تومان","4.9"),
 Service("تدوین ویدئوی کوتاه","استودیو نو","۳۵۰٬۰۰۰ تومان","4.8"),
 Service("ترجمه فارسی و انگلیسی","مهدی مترجم","۱۸۰٬۰۰۰ تومان","4.9"),
 Service("ساخت سایت معرفی کسب‌وکار","وب‌ساز","۱٬۲۰۰٬۰۰۰ تومان","4.7")
)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{KarinoApp()}}
}
@Composable fun KarinoApp(){
 MaterialTheme(colorScheme=lightColorScheme(primary=Primary,background=Bg,surface=Color.White)){
  val nav=rememberNavController()
  Scaffold(bottomBar={Bottom(nav)}){p->
   NavHost(nav,"home",Modifier.padding(p)){
    composable("home"){Home(nav)}
    composable("search"){Search(nav)}
    composable("orders"){Orders()}
    composable("wallet"){Wallet()}
    composable("profile"){Profile()}
    composable("service/{title}"){e->Detail(e.arguments?.getString("title")?:"",nav)}
   }
  }
 }
}
@Composable fun Bottom(nav:NavHostController){
 NavigationBar{
  listOf("home" to Icons.Default.Home to "خانه","search" to Icons.Default.Search to "جستجو",
   "orders" to Icons.Default.ListAlt to "سفارش‌ها","wallet" to Icons.Default.AccountBalanceWallet to "کیف پول",
   "profile" to Icons.Default.Person to "پروفایل").forEach{(r,i,l)->
    NavigationBarItem(nav.currentBackStackEntryAsState().value?.destination?.route==r,
     {nav.navigate(r){launchSingleTop=true}}, {Icon(i,null)},{Text(l)})
  }
 }
}
@Composable fun Home(nav:NavHostController){
 LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  item{Text("سلام 👋",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("چه خدمتی نیاز داری؟",color=Color.Gray)}
  item{OutlinedTextField("",{},Modifier.fillMaxWidth(),placeholder={Text("جستجوی خدمت...")},leadingIcon={Icon(Icons.Default.Search,null)},shape=RoundedCornerShape(16.dp))}
  item{Text("دسته‌بندی‌ها",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(top=8.dp)){
   listOf("طراحی","برنامه‌نویسی","ترجمه","آموزش").forEach{AssistChip({},{Text(it)})}}}
  item{Text("خدمات پیشنهادی",fontWeight=FontWeight.Bold)}
  items(services){s->Card(Modifier.fillMaxWidth().clickable{nav.navigate("service/${s.title}")},RoundedCornerShape(18.dp)){
   Column(Modifier.padding(16.dp)){Text(s.title,fontWeight=FontWeight.Bold);Text(s.seller,color=Color.Gray);Spacer(Modifier.height(8.dp))
   Row(Modifier.fillMaxWidth(),Arrangement.SpaceBetween){Text(s.price,color=Primary,fontWeight=FontWeight.Bold);Text("★ ${s.rating}")}}}}
 }
}
@Composable fun Search(nav:NavHostController){Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){
 Text("جستجو",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp))
 OutlinedTextField("",{},Modifier.fillMaxWidth(),placeholder={Text("نام خدمت یا مهارت...")});Spacer(Modifier.height(16.dp))
 services.forEach{s->Text(s.title,Modifier.fillMaxWidth().clickable{nav.navigate("service/${s.title}")}.padding(18.dp),fontWeight=FontWeight.Bold)}
}}
@Composable fun Detail(title:String,nav:NavHostController){Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)){
 IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
 Spacer(Modifier.height(12.dp));Text("توضیحات خدمت، نمونه‌کار، زمان تحویل و شرایط سفارش در این صفحه قرار می‌گیرد.")
 Spacer(Modifier.weight(1f));Button({nav.navigate("orders")},Modifier.fillMaxWidth()){Text("ثبت سفارش")}}}
@Composable fun Orders(){Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){Text("سفارش‌های من",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Text("سفارشی ثبت نشده است.",color=Color.Gray)}}
@Composable fun Wallet(){Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){Text("کیف پول",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp))
 Card(Modifier.fillMaxWidth(),RoundedCornerShape(20.dp)){Column(Modifier.padding(20.dp)){Text("موجودی",color=Color.Gray);Text("۰ تومان",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));Button({},Modifier.fillMaxWidth()){Text("افزایش موجودی")}}}
 Spacer(Modifier.height(12.dp));Text("روش‌های تسویه: کارت‌به‌کارت، پایا، ساتنا",color=Color.Gray)}}
@Composable fun Profile(){Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){Text("پروفایل",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Text("نام کاربر",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("متخصص خدمات دیجیتال",color=Color.Gray);Spacer(Modifier.height(20.dp));OutlinedButton({},Modifier.fillMaxWidth()){Text("ویرایش پروفایل")}}}

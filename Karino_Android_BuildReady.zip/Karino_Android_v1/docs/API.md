# API v1
POST /api/auth/demo-login
GET /api/services
POST /api/orders
GET /api/health

Planned production endpoints:
auth OTP, profile, service CRUD, orders, chat, wallet, payment receipt, payout, notifications, admin moderation.

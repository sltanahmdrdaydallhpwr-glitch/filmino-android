# ساخت APK کارینو با گوشی

این پروژه Workflow آماده GitHub Actions دارد.

1. یک Repository جدید در GitHub بساز.
2. محتویات پوشه `Karino_Android_v1` را داخل Repository قرار بده.
3. به بخش Actions برو.
4. Workflow با نام `Build Karino APK` را انتخاب کن.
5. گزینه Run workflow را بزن.
6. بعد از موفقیت Build، در همان اجرای Workflow بخش Artifacts را باز کن.
7. فایل `Karino-debug-apk` را دریافت کن.

این APK نسخه Debug برای تست است. برای انتشار عمومی در Google Play یا توزیع حرفه‌ای، باید نسخه Release با کلید امضای اختصاصی ساخته شود.

import express from "express";import cors from "cors";import jwt from "jsonwebtoken";import dotenv from "dotenv";import {Pool} from "pg";
dotenv.config();const app=express();app.use(cors());app.use(express.json());const pool=new Pool({connectionString:process.env.DATABASE_URL});
app.get("/api/health",(_,r)=>r.json({ok:true,service:"karino-api"}));
app.post("/api/auth/demo-login",(q,r)=>{const {phone}=q.body;if(!phone)return r.status(400).json({message:"phone required"});const token=jwt.sign({phone},process.env.JWT_SECRET||"dev-secret",{expiresIn:"7d"});r.json({token,user:{phone}})});
app.get("/api/services",async(_,r)=>{try{r.json((await pool.query("select * from services where status='ACTIVE' order by created_at desc")).rows)}catch{r.status(500).json({message:"database error"})}});
app.post("/api/orders",async(q,r)=>{const {serviceId,buyerId,price}=q.body;if(!serviceId||!buyerId||!price)return r.status(400).json({message:"missing fields"});try{r.status(201).json((await pool.query("insert into orders(service_id,buyer_id,total_amount,status) values($1,$2,$3,'PENDING') returning *",[serviceId,buyerId,price])).rows[0])}catch{r.status(500).json({message:"database error"})}});
app.listen(Number(process.env.PORT||3000),()=>console.log("Karino API :3000"));
